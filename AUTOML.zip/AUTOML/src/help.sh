streamlit run app.py --server.enableXsrfProtection false

streamlit run data_page1.py --server.enableXsrfProtection false